<?php
session_start(); 
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../presentation/account/login.html");
    exit();
  }
include('../../data/connect.php');
// Retrieve data from session
$passData = isset($_SESSION["passData"]) ? $_SESSION["passData"] : [];
$fileNames = isset($_SESSION["fileNames"]) ? $_SESSION["fileNames"] : [];
$user_id = $_SESSION['data']['user_id'];
$dob = ""; 
$pass_type = "";
$pass_zone = ""; 
$class = ""; 
$course = ""; 
$pass_cost = 0; 
$pass_status = "Inactive"; 
$adh = "";
$adhar_document_path = "";
$other_document_path = "";
$bonafide_document_path = "";
$id_card_document_path = "";
$Comment="";
$validity_start="" ;
$validity_end="";
$approval_status="Inactive";
// Check if the required data is present
if (!empty($passData) && !empty($fileNames)) {
    $pass_type = $passData["passType"];
    if ($passData["passType"] === "daily") {
        $adh = $passData["adhaar"];
        $pass_zone = $passData["zone"];
        $adhar_document_path = $fileNames["adh"];
        if ($passData["zone"] === "pp") {
            $cost = 50;
        } else {
            $cost = 120;
        }
        $approval_status="Active";
    } elseif ($passData["passType"] === "monthly") {
    
        $adh = $passData["adhaar"];
        $pass_zone = $passData["zone"];
        $adhar_document_path = $fileNames["adh"];
        if ($passData["zone"] === "pp") {
            $cost = 1200;
        } else {
            $cost = 1700;
        }
    } elseif ($passData["passType"] === "senior") {
        $adh = $passData["adhaar"];
        $pass_zone = $passData["zone"];
        $adhar_document_path = $fileNames["adh"];
        $dob = $passData["dob"];
        $cost = 500;
    } elseif ($passData["passType"] === "student") {
       
        $class = $passData["class"]; 
        $course = $passData["course"];
        $dob = $passData["dob"];
        $bonafide_document_path = $fileNames["bonafide"];
        $id_card_document_path = $fileNames["idcard"];
        $adhar_document_path = $fileNames["adh"];
        $cost = 750;
    }

    echo '</pre>';
} 
else {
    header("Location: pass.php");
    exit;
}
if($pass_type==='daily')
{
$date = date('Y-m-d');
}
else
{
    $currentDate = new DateTime();
    $date = $currentDate->modify('+1 month')->format('Y-m-d');

}
$check=mysqli_query($conn, "SELECT * FROM passes WHERE user_id='$user_id' AND pass_type='$pass_type' AND validity_end='$date' AND pass_zone='$pass_zone'");
if(mysqli_num_rows($check) > 0)
{
    echo "
    <script>
        alert('You already have this type of pass with validity!!!! ');
        window.location.href = './pass.php'; // Redirect to login page or any other page
    </script>
    ";

}
else{
$insert = mysqli_query($conn, "INSERT INTO `passes`(`user_id`, `dob`, `pass_type`, `pass_zone`, `class`, `course`, `pass_cost`, `pass_status`, `adh`, `adhar_document_path`, `other_document_path`, `bonafide_document_path`, `id_card_document_path`, `created_at`, `updated_at`, `Comment`, `validity_start`, `validity_end`, `approval_status`)
VALUES ('$user_id', '$dob', '$pass_type', '$pass_zone', '$class', '$course', '$cost', '$pass_status', '$adh', '$adhar_document_path', '$other_document_path', '$bonafide_document_path', '$id_card_document_path', NOW(), NOW(), '$Comment', '$validity_start', '$validity_end', '$approval_status');");

echo '<script>
alert("Applied For Pass Sucessfully");
window.location = "./pass.php";
</script>';
unset($_SESSION["passData"]);
unset($_SESSION["fileNames"]);
}
?>

