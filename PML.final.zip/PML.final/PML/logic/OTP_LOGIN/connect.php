<?php
$connect=mysqli_connect("localhost","root","","pml") or die("Connection Failed");
?>